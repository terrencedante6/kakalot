import React from 'react';
import LandingPage from '../app/landing/landingpage';

const Home = () => {
  return <LandingPage />;
};

export default Home;
