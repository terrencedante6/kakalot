import React from 'react';
import Layout from '../layout'; 
import styles from './page.module.scss';

const AnnouncementPage = () => {
  return (
    <Layout contentClassName={styles.announcementContent}>

    </Layout>
  );
};

export default AnnouncementPage;
