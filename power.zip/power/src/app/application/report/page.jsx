import React from 'react';
import Layout from '../layout'; 
import styles from './report.module.scss';

const ReportPage = () => {
  return (
    <Layout contentClassName={styles.reportContent}>

    </Layout>
  );
};

export default ReportPage;
