
import React from 'react';
import Layout from '../layout'; 
import styles from './mobilerequest.module.scss';

const MobileRequestPage = () => {
  return (
    <Layout>

    </Layout>
  );
};

export default MobileRequestPage;
