/** @type {import('next').NextConfig} */
const nextConfig = {
  pageExtensions: ['jsx', 'js', 'ts', 'tsx'],
};

export default nextConfig;
